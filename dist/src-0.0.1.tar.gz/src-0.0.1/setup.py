from setuptools import setup, find_packages # type: ignore

setup(
    name= "src" ,
    version= "0.0.1",
    description="its a wine Q package", 
    author= "Abdulrahman", 
    packages=find_packages(), 
    license="MIT"
)


